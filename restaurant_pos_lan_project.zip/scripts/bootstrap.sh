#!/usr/bin/env bash
set -euo pipefail

# Run this from the extracted project directory after installing Flutter.
# It creates/refreshes native platform scaffolding without overwriting lib/.
flutter create . --platforms=android --project-name restaurant_pos_lan
flutter pub get
echo "Bootstrap complete. Now run: flutterfire configure"
