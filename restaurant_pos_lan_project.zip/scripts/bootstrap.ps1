$ErrorActionPreference = "Stop"
flutter create . --platforms=android --project-name restaurant_pos_lan
flutter pub get
Write-Host "Bootstrap complete. Now run: flutterfire configure"
