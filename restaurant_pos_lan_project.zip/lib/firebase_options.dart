import 'package:firebase_core/firebase_core.dart';

/// Run `flutterfire configure` in the real project to replace this file.
///
/// The fallback intentionally throws so the app can continue in offline mode
/// when Firebase has not yet been configured.
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    throw UnsupportedError(
      'Firebase is not configured. Run flutterfire configure.',
    );
  }
}
