String buildUpiUri({
  required String pa,
  required String pn,
  required double amount,
  String? tn,
}) {
  final params = <String, String>{
    'pa': pa,
    'pn': pn,
    'am': amount.toStringAsFixed(2),
    'cu': 'INR',
    if (tn != null && tn.isNotEmpty) 'tn': tn,
  };
  final query = params.entries
      .map((e) => '${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value)}')
      .join('&');
  return 'upi://pay?$query';
}
