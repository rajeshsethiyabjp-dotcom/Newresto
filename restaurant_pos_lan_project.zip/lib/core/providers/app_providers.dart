import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../db/app_database.dart';
import '../services/cloud_service.dart';
import '../services/lan_hub_service.dart';
import '../services/license_service.dart';

final databaseProvider = Provider<AppDatabase>((ref) => throw UnimplementedError());
final cloudServiceProvider = Provider<CloudService>((ref) => throw UnimplementedError());
final licenseServiceProvider = Provider<LicenseService>((ref) => throw UnimplementedError());
final lanHubServiceProvider = Provider<LanHubService>((ref) => throw UnimplementedError());

final selectedRoleProvider = StateProvider<String?>((ref) => null);
final masterUnlockedProvider = StateProvider<bool>((ref) => false);
