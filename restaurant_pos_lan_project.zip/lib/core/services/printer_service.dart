import 'dart:typed_data';
import 'package:esc_pos_utils_plus/esc_pos_utils_plus.dart';

class PrinterService {
  Future<Uint8List> buildReceipt({
    required String restaurant,
    required String orderNo,
    required String table,
    required List<Map<String, dynamic>> items,
    required double subtotal,
    required double gst,
    required double total,
    int paperMm = 80,
  }) async {
    final profile = await CapabilityProfile.load();
    final generator = Generator(
      paperMm == 58 ? PaperSize.mm58 : PaperSize.mm80,
      profile,
    );

    final bytes = <int>[];
    bytes.addAll(generator.text(
      restaurant,
      styles: const PosStyles(
        align: PosAlign.center,
        bold: true,
        height: PosTextSize.size2,
        width: PosTextSize.size2,
      ),
    ));
    bytes.addAll(generator.text('Order #$orderNo  Table $table',
        styles: const PosStyles(align: PosAlign.center)));
    bytes.addAll(generator.hr());

    for (final item in items) {
      final qty = item['qty'];
      final name = item['name'];
      final amount = (item['amount'] as num).toDouble();
      bytes.addAll(generator.row([
        PosColumn(text: '$qty x $name', width: 8),
        PosColumn(
          text: amount.toStringAsFixed(2),
          width: 4,
          styles: const PosStyles(align: PosAlign.right),
        ),
      ]));
    }

    bytes.addAll(generator.hr());
    bytes.addAll(generator.row([
      PosColumn(text: 'Subtotal', width: 8),
      PosColumn(
        text: subtotal.toStringAsFixed(2),
        width: 4,
        styles: const PosStyles(align: PosAlign.right),
      ),
    ]));
    bytes.addAll(generator.row([
      PosColumn(text: 'GST', width: 8),
      PosColumn(
        text: gst.toStringAsFixed(2),
        width: 4,
        styles: const PosStyles(align: PosAlign.right),
      ),
    ]));
    bytes.addAll(generator.row([
      PosColumn(text: 'TOTAL', width: 8, styles: const PosStyles(bold: true)),
      PosColumn(
        text: total.toStringAsFixed(2),
        width: 4,
        styles: const PosStyles(align: PosAlign.right, bold: true),
      ),
    ]));
    bytes.addAll(generator.feed(2));
    bytes.addAll(generator.cut());
    return Uint8List.fromList(bytes);
  }
}
