import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as shelf_io;
import 'package:shelf_web_socket/shelf_web_socket.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import '../constants/app_constants.dart';
import '../db/app_database.dart';

class LanHubService {
  final AppDatabase db;
  HttpServer? _server;
  final Set<WebSocketChannel> _clients = {};

  LanHubService({required this.db});

  Future<void> prepare() async {}

  bool get running => _server != null;
  int get port => AppConstants.lanPort;

  Future<void> start() async {
    if (_server != null) return;

    final wsHandler = webSocketHandler((WebSocketChannel socket, String? protocol) {
      _clients.add(socket);
      socket.stream.listen(
        (message) async {
          if (message is String) {
            await _handleMessage(message);
          }
        },
        onDone: () => _clients.remove(socket),
        onError: (_) => _clients.remove(socket),
      );
    });

    final handler = const Pipeline()
        .addMiddleware(logRequests())
        .addHandler((Request request) {
      if (request.url.path == 'ws') return wsHandler(request);
      return Response.ok(
        jsonEncode({
          'service': 'restaurant-pos-lan',
          'status': 'ok',
          'port': AppConstants.lanPort,
        }),
        headers: {'content-type': 'application/json'},
      );
    });

    _server = await shelf_io.serve(handler, InternetAddress.anyIPv4, port);
  }

  Future<void> stop() async {
    for (final c in _clients) {
      await c.sink.close();
    }
    _clients.clear();
    await _server?.close(force: true);
    _server = null;
  }

  Future<void> broadcast(Map<String, dynamic> message) async {
    final encoded = jsonEncode(message);
    for (final client in List.of(_clients)) {
      try {
        client.sink.add(encoded);
      } catch (_) {
        _clients.remove(client);
      }
    }
  }

  Future<void> _handleMessage(String raw) async {
    try {
      final message = jsonDecode(raw) as Map<String, dynamic>;
      final type = message['type'];
      if (type == 'kot.create') {
        await broadcast({...message, 'serverReceivedAt': DateTime.now().toIso8601String()});
      } else if (type == 'kot.void') {
        await broadcast(message);
      } else if (type == 'requisition.create') {
        await broadcast(message);
      } else if (type == 'table.state') {
        await broadcast(message);
      } else {
        await broadcast(message);
      }
    } catch (_) {}
  }
}
