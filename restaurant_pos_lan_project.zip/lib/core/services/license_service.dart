import 'package:shared_preferences/shared_preferences.dart';

import '../constants/app_constants.dart';
import '../db/app_database.dart';
import 'cloud_service.dart';

class LicenseService {
  final AppDatabase db;
  final CloudService cloud;
  bool isLocked = false;
  String? tenantId;
  String? lockReason;

  LicenseService({required this.db, required this.cloud});

  Future<void> bootstrap() async {
    final prefs = await SharedPreferences.getInstance();
    tenantId = prefs.getString('tenant_id');
    if (tenantId == null) return;

    final cachedActive = prefs.getBool('license_active');
    final cachedExpiryMs = prefs.getInt('license_expiry');
    final lastCheckMs = prefs.getInt('license_last_check');

    if (cachedActive == false) {
      isLocked = true;
      lockReason = 'Restaurant license is blocked.';
      return;
    }

    if (cachedExpiryMs != null &&
        DateTime.now().isAfter(DateTime.fromMillisecondsSinceEpoch(cachedExpiryMs))) {
      isLocked = true;
      lockReason = 'Restaurant license has expired.';
    }

    final due = lastCheckMs == null ||
        DateTime.now()
                .difference(DateTime.fromMillisecondsSinceEpoch(lastCheckMs))
                .inHours >=
            AppConstants.cloudBackupIntervalHours;

    if (due && cloud.configured) {
      await validateRemote();
    }
  }

  Future<bool> verifyTenant(String id) async {
    if (!RegExp(r'^REST-[A-Z0-9]{3,}$').hasMatch(id)) return false;
    tenantId = id;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('tenant_id', id);

    if (!cloud.configured) {
      await prefs.setBool('license_active', true);
      return true;
    }

    return (await validateRemote()) || _withinGrace(prefs);
  }

  bool _withinGrace(SharedPreferences prefs) {
    final last = prefs.getInt('license_last_check');
    if (last == null) return true;
    return DateTime.now()
            .difference(DateTime.fromMillisecondsSinceEpoch(last))
            .inDays <=
        AppConstants.licenseGraceDays;
  }

  Future<bool> validateRemote() async {
    final id = tenantId;
    if (id == null) return false;
    try {
      final license = await cloud.fetchLicense(id);
      if (license == null) return false;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('license_active', license.active);
      await prefs.setInt(
          'license_expiry', license.expiry.millisecondsSinceEpoch);
      await prefs.setInt(
          'license_last_check', DateTime.now().millisecondsSinceEpoch);

      if (!license.active || DateTime.now().isAfter(license.expiry)) {
        isLocked = true;
        lockReason = !license.active
            ? 'Restaurant license is blocked remotely.'
            : 'Restaurant license is expired.';
        return false;
      }
      isLocked = false;
      lockReason = null;
      return true;
    } catch (_) {
      final prefs = await SharedPreferences.getInstance();
      return _withinGrace(prefs);
    }
  }
}
