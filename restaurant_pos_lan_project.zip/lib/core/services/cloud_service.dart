import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

import '../../firebase_options.dart';

class CloudLicense {
  final String tenantId;
  final bool active;
  final DateTime expiry;
  CloudLicense({
    required this.tenantId,
    required this.active,
    required this.expiry,
  });
}

class CloudService {
  FirebaseFirestore? _firestore;
  bool get configured => _firestore != null;

  Future<void> initialize() async {
    try {
      await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform,
      );
      _firestore = FirebaseFirestore.instance;
    } catch (_) {
      _firestore = null;
    }
  }

  Future<CloudLicense?> fetchLicense(String tenantId) async {
    final fs = _firestore;
    if (fs == null) return null;
    final snap = await fs.collection('licenses').doc(tenantId).get();
    final data = snap.data();
    if (data == null) return null;
    final expiry = (data['expiry'] as Timestamp?)?.toDate();
    if (expiry == null) return null;
    return CloudLicense(
      tenantId: tenantId,
      active: data['active'] == true,
      expiry: expiry,
    );
  }

  Future<void> backup(String tenantId, Map<String, dynamic> payload) async {
    final fs = _firestore;
    if (fs == null) return;
    await fs.collection('backups').doc(tenantId).collection('snapshots').add({
      ...payload,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
}
