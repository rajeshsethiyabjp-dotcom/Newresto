import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

class ReportService {
  Future<Uint8List> buildZReport({
    required String restaurant,
    required String businessDate,
    required double grossSales,
    required double gst,
    required double expenses,
    required double cash,
    required double upi,
    required Map<String, double> profitSplit,
  }) async {
    final doc = pw.Document();
    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(restaurant, style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
            pw.Text('Z-Report — $businessDate'),
            pw.SizedBox(height: 16),
            pw.Text('Gross Sales: ₹${grossSales.toStringAsFixed(2)}'),
            pw.Text('GST: ₹${gst.toStringAsFixed(2)}'),
            pw.Text('Expenses: ₹${expenses.toStringAsFixed(2)}'),
            pw.Text('Cash: ₹${cash.toStringAsFixed(2)}'),
            pw.Text('UPI: ₹${upi.toStringAsFixed(2)}'),
            pw.SizedBox(height: 12),
            pw.Text('Partner Profit Allocation'),
            ...profitSplit.entries.map(
              (e) => pw.Text('${e.key}: ${e.value.toStringAsFixed(2)}%'),
            ),
          ],
        ),
      ),
    );
    return doc.save();
  }

  Future<void> sharePdf(Uint8List bytes, {String filename = 'z_report.pdf'}) async {
    await Printing.sharePdf(bytes: bytes, filename: filename);
  }
}
