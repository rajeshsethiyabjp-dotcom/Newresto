class AppConstants {
  static const appName = 'Restaurant POS LAN';
  static const lanPort = 8787;
  static const licenseGraceDays = 7;
  static const cloudBackupIntervalHours = 24;
  static const defaultMasterPin = '1234';
  static const defaultPartnerPin = '2468';
  static const gstRates = [5.0, 18.0];
}
