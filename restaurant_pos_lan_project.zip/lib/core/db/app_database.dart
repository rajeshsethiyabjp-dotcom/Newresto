import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  static const _dbName = 'restaurant_pos.db';
  static const _version = 3;
  late Database db;

  Future<void> open() async {
    final path = join(await getDatabasesPath(), _dbName);
    db = await openDatabase(
      path,
      version: _version,
      onCreate: (db, version) async => _create(db),
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) await _migration2(db);
        if (oldVersion < 3) await _migration3(db);
      },
    );
  }

  Future<void> _create(Database db) async {
    await db.execute('''
      CREATE TABLE restaurant(
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        active INTEGER NOT NULL DEFAULT 1,
        license_expiry TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE settings(
        key TEXT PRIMARY KEY,
        value TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE categories(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        active INTEGER NOT NULL DEFAULT 1
      )
    ''');
    await db.execute('''
      CREATE TABLE menu_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        gst_rate REAL NOT NULL DEFAULT 5,
        veg INTEGER NOT NULL DEFAULT 1,
        out_of_stock INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await db.execute('''
      CREATE TABLE orders(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        table_no INTEGER NOT NULL,
        waiter_name TEXT NOT NULL,
        status TEXT NOT NULL,
        created_at TEXT NOT NULL,
        notes TEXT DEFAULT ''
      )
    ''');
    await db.execute('''
      CREATE TABLE order_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        menu_item_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        unit_price REAL NOT NULL,
        quantity INTEGER NOT NULL,
        gst_rate REAL NOT NULL,
        modifiers TEXT DEFAULT '',
        complimentary INTEGER NOT NULL DEFAULT 0,
        wastage INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await db.execute('''
      CREATE TABLE payments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        mode TEXT NOT NULL,
        amount REAL NOT NULL,
        reference TEXT DEFAULT '',
        paid_at TEXT NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE inventory(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        unit TEXT NOT NULL,
        qty REAL NOT NULL DEFAULT 0,
        cost_per_unit REAL NOT NULL DEFAULT 0
      )
    ''');
    await db.execute('''
      CREATE TABLE purchases(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        inventory_id INTEGER NOT NULL,
        supplier TEXT NOT NULL,
        qty REAL NOT NULL,
        cost REAL NOT NULL,
        purchased_at TEXT NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE expenses(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        amount REAL NOT NULL,
        paid_by TEXT NOT NULL,
        created_at TEXT NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE audits(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        actor TEXT NOT NULL,
        action TEXT NOT NULL,
        reason TEXT NOT NULL,
        entity_id TEXT,
        created_at TEXT NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE requisitions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ingredient TEXT NOT NULL,
        qty REAL NOT NULL,
        unit TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'OPEN',
        created_at TEXT NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE day_end(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        business_date TEXT NOT NULL,
        system_cash REAL NOT NULL,
        physical_cash REAL NOT NULL,
        difference REAL NOT NULL,
        approved_by TEXT NOT NULL,
        created_at TEXT NOT NULL
      )
    ''');
  }

  Future<void> _migration2(Database db) async {
    await db.execute('ALTER TABLE orders ADD COLUMN notes TEXT DEFAULT ""');
  }

  Future<void> _migration3(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS requisitions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ingredient TEXT NOT NULL,
        qty REAL NOT NULL,
        unit TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'OPEN',
        created_at TEXT NOT NULL
      )
    ''');
  }

  Future<List<Map<String, dynamic>>> query(String table,
      {String? where, List<Object?>? whereArgs}) {
    return db.query(table, where: where, whereArgs: whereArgs);
  }

  Future<int> insert(String table, Map<String, Object?> values) {
    return db.insert(table, values);
  }

  Future<int> update(String table, Map<String, Object?> values,
      {String? where, List<Object?>? whereArgs}) {
    return db.update(table, values, where: where, whereArgs: whereArgs);
  }

  Future<int> delete(String table, {String? where, List<Object?>? whereArgs}) {
    return db.delete(table, where: where, whereArgs: whereArgs);
  }

  Future<List<Map<String, Object?>>> rawQuery(String sql,
      [List<Object?>? args]) {
    return db.rawQuery(sql, args);
  }
}
