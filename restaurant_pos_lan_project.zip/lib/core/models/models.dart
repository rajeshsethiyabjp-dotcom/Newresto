enum UserRole { master, waiter, kitchen, partner }

enum TableState { vacant, running, billRequested }

enum PaymentMode { cash, upi, split }

class Restaurant {
  final String id;
  final String name;
  final bool active;
  final DateTime? licenseExpiry;
  Restaurant({
    required this.id,
    required this.name,
    required this.active,
    this.licenseExpiry,
  });
}

class MenuCategory {
  final int? id;
  final String name;
  final bool active;
  MenuCategory({this.id, required this.name, this.active = true});
}

class MenuItem {
  final int? id;
  final int categoryId;
  final String name;
  final double price;
  final double gstRate;
  final bool veg;
  final bool outOfStock;
  MenuItem({
    this.id,
    required this.categoryId,
    required this.name,
    required this.price,
    this.gstRate = 5,
    this.veg = true,
    this.outOfStock = false,
  });
}

class OrderItem {
  final int? id;
  final int orderId;
  final int menuItemId;
  final String name;
  final double unitPrice;
  final int quantity;
  final double gstRate;
  final String modifiers;
  final bool complimentary;
  final bool wastage;
  OrderItem({
    this.id,
    required this.orderId,
    required this.menuItemId,
    required this.name,
    required this.unitPrice,
    required this.quantity,
    required this.gstRate,
    this.modifiers = '',
    this.complimentary = false,
    this.wastage = false,
  });

  double get effectivePrice => complimentary ? 0 : unitPrice;
  double get lineTotal => effectivePrice * quantity;
}

class Order {
  final int? id;
  final int tableNo;
  final String waiterName;
  final String status;
  final DateTime createdAt;
  final List<OrderItem> items;
  Order({
    this.id,
    required this.tableNo,
    required this.waiterName,
    required this.status,
    required this.createdAt,
    this.items = const [],
  });

  double get subtotal => items.fold(0, (a, b) => a + b.lineTotal);
  double get gst => items.fold(
        0,
        (a, b) => a + (b.lineTotal * b.gstRate / 100),
      );
  double get grandTotal => subtotal + gst;
  double get roundedTotal => grandTotal.roundToDouble();
  double get roundOff => roundedTotal - grandTotal;
}

class Payment {
  final int orderId;
  final PaymentMode mode;
  final double amount;
  final String reference;
  Payment({
    required this.orderId,
    required this.mode,
    required this.amount,
    this.reference = '',
  });
}
