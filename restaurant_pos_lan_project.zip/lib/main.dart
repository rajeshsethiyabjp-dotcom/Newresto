import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';
import 'core/db/app_database.dart';
import 'core/services/cloud_service.dart';
import 'core/services/lan_hub_service.dart';
import 'core/services/license_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final db = AppDatabase();
  await db.open();

  final cloud = CloudService();
  await cloud.initialize();

  final license = LicenseService(db: db, cloud: cloud);
  await license.bootstrap();

  final lan = LanHubService(db: db);
  await lan.prepare();

  runApp(
    ProviderScope(
      overrides: [
        databaseProvider.overrideWithValue(db),
        cloudServiceProvider.overrideWithValue(cloud),
        licenseServiceProvider.overrideWithValue(license),
        lanHubServiceProvider.overrideWithValue(lan),
      ],
      child: const RestaurantPosApp(),
    ),
  );
}
