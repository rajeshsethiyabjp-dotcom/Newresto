import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/providers/app_providers.dart';

class WaiterScreen extends ConsumerStatefulWidget {
  const WaiterScreen({super.key});
  @override
  ConsumerState<WaiterScreen> createState() => _WaiterScreenState();
}

class _WaiterScreenState extends ConsumerState<WaiterScreen> {
  int table = 1;
  String category = 'All';
  String query = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Waiter / Captain')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(child: TextField(
                  onChanged: (v) => setState(() => query = v),
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search menu', border: OutlineInputBorder()),
                )),
                const SizedBox(width: 8),
                DropdownButton<int>(
                  value: table,
                  items: List.generate(12, (i) => DropdownMenuItem(value: i + 1, child: Text('T${i + 1}'))),
                  onChanged: (v) => setState(() => table = v ?? 1),
                ),
              ],
            ),
          ),
          Wrap(
            spacing: 8,
            children: ['All', 'Starters', 'Main Course', 'Drinks'].map(
              (c) => ChoiceChip(label: Text(c), selected: category == c, onSelected: (_) => setState(() => category = c)),
            ).toList(),
          ),
          Expanded(
            child: ListView(
              children: [
                _item('Paneer Tikka', 220),
                _item('Butter Naan', 45),
                _item('Dal Tadka', 180),
                _item('Cold Drink', 60),
              ].where((w) => w.key.toString().toLowerCase().contains(query.toLowerCase())).toList(),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final lan = ref.read(lanHubServiceProvider);
          await lan.broadcast({
            'type': 'kot.create',
            'tenantId': 'local',
            'deviceId': 'waiter',
            'payload': {'table': table, 'waiter': 'Captain', 'items': ['Paneer Tikka']},
          });
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('KOT sent to Kitchen & Billing')));
        },
        icon: const Icon(Icons.send),
        label: const Text('Send KOT'),
      ),
    );
  }

  Widget _item(String name, double price) => Card(
    child: ListTile(
      title: Text(name),
      trailing: Text('₹${price.toStringAsFixed(0)}'),
      onTap: () {},
    ),
  );
}
