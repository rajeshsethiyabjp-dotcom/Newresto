import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/providers/app_providers.dart';

class ExpenseScreen extends ConsumerStatefulWidget {
  const ExpenseScreen({super.key});
  @override
  ConsumerState<ExpenseScreen> createState() => _ExpenseScreenState();
}

class _ExpenseScreenState extends ConsumerState<ExpenseScreen> {
  final title = TextEditingController();
  final amount = TextEditingController();
  String paidBy = 'Cash Box';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Petty Cash & Expenses')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: title, decoration: const InputDecoration(labelText: 'Expense', border: OutlineInputBorder())),
            const SizedBox(height: 8),
            TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Amount', border: OutlineInputBorder())),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: paidBy,
              items: const [
                DropdownMenuItem(value: 'Cash Box', child: Text('Cash Box')),
                DropdownMenuItem(value: 'Partner A', child: Text('Partner A')),
                DropdownMenuItem(value: 'Partner B', child: Text('Partner B')),
              ],
              onChanged: (v) => setState(() => paidBy = v ?? paidBy),
              decoration: const InputDecoration(labelText: 'Paid By', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () async {
                await ref.read(databaseProvider).insert('expenses', {
                  'title': title.text.trim(),
                  'amount': double.tryParse(amount.text) ?? 0,
                  'paid_by': paidBy,
                  'created_at': DateTime.now().toIso8601String(),
                });
                if (mounted) Navigator.pop(context);
              },
              child: const Text('Save Expense'),
            ),
          ],
        ),
      ),
    );
  }
}
