import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/providers/app_providers.dart';

class MenuManagerScreen extends ConsumerStatefulWidget {
  const MenuManagerScreen({super.key});
  @override
  ConsumerState<MenuManagerScreen> createState() => _MenuManagerScreenState();
}

class _MenuManagerScreenState extends ConsumerState<MenuManagerScreen> {
  final category = TextEditingController();
  final item = TextEditingController();
  final price = TextEditingController();
  bool veg = true;
  bool out = false;
  double gst = 5;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Menu Manager')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(controller: category, decoration: const InputDecoration(labelText: 'Category', border: OutlineInputBorder())),
          const SizedBox(height: 8),
          TextField(controller: item, decoration: const InputDecoration(labelText: 'Item', border: OutlineInputBorder())),
          const SizedBox(height: 8),
          TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Price', border: OutlineInputBorder())),
          SwitchListTile(title: const Text('Veg'), value: veg, onChanged: (v) => setState(() => veg = v)),
          SwitchListTile(title: const Text('Out of Stock'), value: out, onChanged: (v) => setState(() => out = v)),
          DropdownButtonFormField<double>(
            value: gst,
            decoration: const InputDecoration(labelText: 'GST', border: OutlineInputBorder()),
            items: const [
              DropdownMenuItem(value: 5, child: Text('5%')),
              DropdownMenuItem(value: 18, child: Text('18%')),
            ],
            onChanged: (v) => setState(() => gst = v ?? 5),
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: () async {
              final db = ref.read(databaseProvider);
              var rows = await db.query('categories', where: 'name = ?', whereArgs: [category.text.trim()]);
              int categoryId;
              if (rows.isEmpty) {
                categoryId = await db.insert('categories', {'name': category.text.trim(), 'active': 1});
              } else {
                categoryId = rows.first['id'] as int;
              }
              await db.insert('menu_items', {
                'category_id': categoryId,
                'name': item.text.trim(),
                'price': double.tryParse(price.text) ?? 0,
                'gst_rate': gst,
                'veg': veg ? 1 : 0,
                'out_of_stock': out ? 1 : 0,
              });
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Menu item saved')));
            },
            child: const Text('Save Item'),
          ),
        ],
      ),
    );
  }
}
