import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/providers/app_providers.dart';

class InventoryScreen extends ConsumerStatefulWidget {
  const InventoryScreen({super.key});
  @override
  ConsumerState<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends ConsumerState<InventoryScreen> {
  final name = TextEditingController();
  final qty = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Inventory & Kitchen Requisition')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Raw material', border: OutlineInputBorder())),
            const SizedBox(height: 8),
            TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantity', border: OutlineInputBorder())),
            const SizedBox(height: 8),
            FilledButton(
              onPressed: () async {
                await ref.read(databaseProvider).insert('requisitions', {
                  'ingredient': name.text.trim(),
                  'qty': double.tryParse(qty.text) ?? 0,
                  'unit': 'kg',
                  'status': 'OPEN',
                  'created_at': DateTime.now().toIso8601String(),
                });
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kitchen demand recorded')));
              },
              child: const Text('Send Demand'),
            ),
          ],
        ),
      ),
    );
  }
}
