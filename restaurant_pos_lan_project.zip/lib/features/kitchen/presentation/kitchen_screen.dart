import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:audioplayers/audioplayers.dart';

import '../../../core/providers/app_providers.dart';

class KitchenScreen extends ConsumerStatefulWidget {
  const KitchenScreen({super.key});
  @override
  ConsumerState<KitchenScreen> createState() => _KitchenScreenState();
}

class _KitchenScreenState extends ConsumerState<KitchenScreen> {
  final player = AudioPlayer();
  final tickets = <Map<String, dynamic>>[];
  StreamSubscription? sub;

  @override
  void initState() {
    super.initState();
    // A client build can subscribe to the Master's WebSocket endpoint here.
    // The server broadcasts the same KOT envelope to all connected screens.
  }

  @override
  void dispose() {
    sub?.cancel();
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Kitchen Display System')),
      body: tickets.isEmpty
          ? const Center(child: Text('Waiting for KOT…'))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: tickets.length,
              itemBuilder: (_, i) {
                final t = tickets[i];
                return Card(
                  child: ListTile(
                    leading: const Icon(Icons.restaurant),
                    title: Text('Table ${t['table']} — ${t['waiter']}'),
                    subtitle: Text((t['items'] as List).join(', ')),
                    trailing: const Text('NEW'),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addDemoTicket(),
        icon: const Icon(Icons.notifications_active),
        label: const Text('Demo KOT'),
      ),
    );
  }

  Future<void> _addDemoTicket() async {
    setState(() {
      tickets.insert(0, {
        'table': 4,
        'waiter': 'Captain',
        'items': ['Paneer Tikka', 'Butter Naan'],
        'createdAt': DateTime.now(),
      });
    });
    await player.play(AssetSource('beep.mp3')).catchError((_) {});
  }
}
