import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/providers/app_providers.dart';

class PartnerScreen extends ConsumerWidget {
  const PartnerScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text('Partner Read-Only Audit')),
      body: FutureBuilder<List<Map<String, Object?>>>(
        future: ref.read(databaseProvider).rawQuery(
          'SELECT business_date, system_cash, physical_cash, difference, approved_by FROM day_end ORDER BY id DESC LIMIT 30',
        ),
        builder: (_, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final rows = snap.data!;
          if (rows.isEmpty) return const Center(child: Text('No day-end audits yet.'));
          return ListView.builder(
            itemCount: rows.length,
            itemBuilder: (_, i) => ListTile(
              title: Text(rows[i]['business_date'].toString()),
              subtitle: Text('System ₹${rows[i]['system_cash']} • Physical ₹${rows[i]['physical_cash']}'),
              trailing: Text('Diff ₹${rows[i]['difference']}'),
            ),
          );
        },
      ),
    );
  }
}
