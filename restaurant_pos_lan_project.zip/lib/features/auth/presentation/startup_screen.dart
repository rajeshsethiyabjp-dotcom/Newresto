import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/providers/app_providers.dart';
import 'role_selection_screen.dart';

class StartupScreen extends ConsumerStatefulWidget {
  const StartupScreen({super.key});

  @override
  ConsumerState<StartupScreen> createState() => _StartupScreenState();
}

class _StartupScreenState extends ConsumerState<StartupScreen> {
  final controller = TextEditingController();
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    final license = ref.read(licenseServiceProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Restaurant Verification')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 440),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.restaurant, size: 72),
                const SizedBox(height: 24),
                TextField(
                  controller: controller,
                  textCapitalization: TextCapitalization.characters,
                  decoration: const InputDecoration(
                    labelText: 'Restaurant ID',
                    hintText: 'REST-XXX',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: busy
                      ? null
                      : () async {
                          setState(() => busy = true);
                          final ok = await license.verifyTenant(
                            controller.text.trim().toUpperCase(),
                          );
                          if (!mounted) return;
                          setState(() => busy = false);
                          if (ok) {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const RoleSelectionScreen(),
                              ),
                            );
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  license.lockReason ??
                                      'Restaurant ID could not be verified.',
                                ),
                              ),
                            );
                          }
                        },
                  child: Text(busy ? 'Checking…' : 'Continue'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
