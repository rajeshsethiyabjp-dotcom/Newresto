import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/models/models.dart';
import '../../../core/providers/app_providers.dart';
import '../../../core/utils/security.dart';
import '../../billing/presentation/billing_screen.dart';
import '../../kitchen/presentation/kitchen_screen.dart';
import '../../partner/presentation/partner_screen.dart';
import '../../waiter/presentation/waiter_screen.dart';

class RoleSelectionScreen extends ConsumerWidget {
  const RoleSelectionScreen({super.key});

  Future<bool> _pin(BuildContext context, String expected) async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Enter 4-digit PIN'),
        content: TextField(
          controller: c,
          keyboardType: TextInputType.number,
          maxLength: 4,
          obscureText: true,
          decoration: const InputDecoration(border: OutlineInputBorder()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, verifyPin(c.text, expected)), child: const Text('Unlock')),
        ],
      ),
    );
    return ok ?? false;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    const masterHash = '03ac674216f3e15c761ee1a5e255f067953623c8e0f3c0c9a4a6a7f5f0b0c6d7';
    const partnerHash = '5a0c9a2a4f6c3b0e7e9e2e6f0f5b7f4f5f1e6c3e9f8b2d1a7a5c4e3f2b1d0c9';
    // The hashes above are placeholders for deployment. Use Settings to replace them.
    return Scaffold(
      appBar: AppBar(title: const Text('Select Role')),
      body: GridView.count(
        padding: const EdgeInsets.all(24),
        crossAxisCount: MediaQuery.of(context).size.width > 700 ? 4 : 2,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        children: [
          _RoleCard(
            icon: Icons.point_of_sale,
            title: 'Billing & Master Admin',
            onTap: () async {
              final ok = await _pin(context, hashPin('1234'));
              if (!context.mounted || !ok) return;
              ref.read(masterUnlockedProvider.notifier).state = true;
              Navigator.push(context, MaterialPageRoute(builder: (_) => const BillingScreen()));
            },
          ),
          _RoleCard(
            icon: Icons.room_service,
            title: 'Waiter / Captain',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WaiterScreen())),
          ),
          _RoleCard(
            icon: Icons.soup_kitchen,
            title: 'Kitchen Display',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const KitchenScreen())),
          ),
          _RoleCard(
            icon: Icons.visibility,
            title: 'Partner Read-Only',
            onTap: () async {
              final ok = await _pin(context, hashPin('2468'));
              if (!context.mounted || !ok) return;
              Navigator.push(context, MaterialPageRoute(builder: (_) => const PartnerScreen()));
            },
          ),
        ],
      ),
    );
  }
}

class _RoleCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  const _RoleCard({required this.icon, required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) => Card(
    child: InkWell(
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 56),
          const SizedBox(height: 12),
          Text(title, textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleMedium),
        ],
      ),
    ),
  );
}
