import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/providers/app_providers.dart';
import '../../../core/services/report_service.dart';

class ZReportScreen extends ConsumerWidget {
  const ZReportScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text('Z-Report')),
      body: Center(
        child: FilledButton.icon(
          icon: const Icon(Icons.picture_as_pdf),
          label: const Text('Generate & Share Daily Z-Report'),
          onPressed: () async {
            final report = ReportService();
            final bytes = await report.buildZReport(
              restaurant: ref.read(licenseServiceProvider).tenantId ?? 'Restaurant',
              businessDate: DateTime.now().toIso8601String().substring(0, 10),
              grossSales: 0,
              gst: 0,
              expenses: 0,
              cash: 0,
              upi: 0,
              profitSplit: const {'Partner A': 50, 'Partner B': 50},
            );
            await report.sharePdf(bytes);
          },
        ),
      ),
    );
  }
}
