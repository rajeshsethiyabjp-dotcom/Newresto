import 'package:flutter/foundation.dart';

import '../../core/db/app_database.dart';

class AuditRepository {
  final AppDatabase db;
  AuditRepository(this.db);

  Future<void> log({
    required String actor,
    required String action,
    required String reason,
    String? entityId,
  }) async {
    await db.insert('audits', {
      'actor': actor,
      'action': action,
      'reason': reason,
      'entity_id': entityId,
      'created_at': DateTime.now().toIso8601String(),
    });
    debugPrint('AUDIT $actor $action $reason $entityId');
  }
}
