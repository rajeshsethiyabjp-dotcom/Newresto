import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/db/app_database.dart';
import '../../../core/providers/app_providers.dart';
import '../../../core/services/lan_hub_service.dart';
import '../../../core/services/printer_service.dart';
import '../../../core/utils/upi.dart';
import '../../reports/presentation/z_report_screen.dart';

class BillingScreen extends ConsumerStatefulWidget {
  const BillingScreen({super.key});
  @override
  ConsumerState<BillingScreen> createState() => _BillingScreenState();
}

class _BillingScreenState extends ConsumerState<BillingScreen> {
  final printer = PrinterService();
  int? selectedTable;
  List<Map<String, dynamic>> items = [];

  Future<void> _addDemoItem() async {
    setState(() {
      items.add({
        'name': 'Paneer Tikka',
        'qty': 1,
        'amount': 220.0,
        'gst': 5.0,
      });
    });
  }

  double get subtotal => items.fold(0, (a, b) => a + (b['amount'] as double) * (b['qty'] as int));
  double get gst => items.fold(0, (a, b) => a + (b['amount'] as double) * (b['qty'] as int) * (b['gst'] as double) / 100);
  double get total => (subtotal + gst).roundToDouble();

  @override
  Widget build(BuildContext context) {
    final lan = ref.read(lanHubServiceProvider);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Billing & Master'),
        actions: [
          IconButton(
            tooltip: 'Start LAN Hub',
            onPressed: () async {
              await lan.start();
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('LAN Hub: ${lan.port}')));
            },
            icon: const Icon(Icons.wifi),
          ),
          IconButton(
            tooltip: 'Z Report',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ZReportScreen())),
            icon: const Icon(Icons.summarize),
          ),
        ],
      ),
      body: Row(
        children: [
          Expanded(flex: 3, child: _floorMap()),
          Expanded(flex: 5, child: _checkout()),
        ],
      ),
    );
  }

  Widget _floorMap() {
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
      ),
      itemCount: 12,
      itemBuilder: (_, i) {
        final table = i + 1;
        final active = selectedTable == table;
        return Card(
          color: active ? Colors.amber.shade200 : Colors.green.shade200,
          child: InkWell(
            onTap: () => setState(() => selectedTable = table),
            child: Center(child: Text('Table $table', style: const TextStyle(fontWeight: FontWeight.bold))),
          ),
        );
      },
    );
  }

  Widget _checkout() {
    final upi = buildUpiUri(
      pa: 'restaurant@upi',
      pn: 'Restaurant',
      amount: total,
      tn: 'Table ${selectedTable ?? '-'}',
    );

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Table ${selectedTable ?? '-'}', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          Expanded(
            child: ListView(
              children: [
                for (final item in items)
                  ListTile(
                    title: Text(item['name']),
                    subtitle: Text('${item['qty']} × ₹${item['amount']}  GST ${item['gst']}%'),
                    trailing: IconButton(
                      icon: const Icon(Icons.free_breakfast),
                      tooltip: 'Complimentary',
                      onPressed: () => setState(() => item['amount'] = 0.0),
                    ),
                  ),
                if (items.isEmpty)
                  const Center(child: Padding(padding: EdgeInsets.all(40), child: Text('No items'))),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [const Text('Subtotal'), Text('₹${subtotal.toStringAsFixed(2)}')],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [const Text('GST'), Text('₹${gst.toStringAsFixed(2)}')],
          ),
          const Divider(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('TOTAL', style: TextStyle(fontWeight: FontWeight.bold)),
              Text('₹${total.toStringAsFixed(2)}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: OutlinedButton(onPressed: _addDemoItem, child: const Text('Add Item'))),
              const SizedBox(width: 8),
              Expanded(child: FilledButton(onPressed: selectedTable == null ? null : () => _checkoutNow(upi), child: const Text('Checkout'))),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _checkoutNow(String upi) async {
    final db = ref.read(databaseProvider);
    final orderId = await db.insert('orders', {
      'table_no': selectedTable!,
      'waiter_name': 'Billing',
      'status': 'PAID',
      'created_at': DateTime.now().toIso8601String(),
      'notes': '',
    });
    await db.insert('payments', {
      'order_id': orderId,
      'mode': 'cash',
      'amount': total,
      'reference': '',
      'paid_at': DateTime.now().toIso8601String(),
    });
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Payment'),
        content: Text('Cash ₹${total.toStringAsFixed(2)}\n\nUPI URI:\n$upi'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Done'))],
      ),
    );
  }
}
