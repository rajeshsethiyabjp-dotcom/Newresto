import '../../../core/db/app_database.dart';
import '../../../core/models/models.dart';
import '../../audit/audit_repository.dart';

class BillingRepository {
  final AppDatabase db;
  late final AuditRepository audit;

  BillingRepository(this.db) {
    audit = AuditRepository(db);
  }

  Future<int> createOrder({
    required int tableNo,
    required String waiter,
    required List<OrderItem> items,
    String notes = '',
  }) async {
    return db.db.transaction((txn) async {
      final orderId = await txn.insert('orders', {
        'table_no': tableNo,
        'waiter_name': waiter,
        'status': 'OPEN',
        'created_at': DateTime.now().toIso8601String(),
        'notes': notes,
      });
      for (final item in items) {
        await txn.insert('order_items', {
          'order_id': orderId,
          'menu_item_id': item.menuItemId,
          'name': item.name,
          'unit_price': item.unitPrice,
          'quantity': item.quantity,
          'gst_rate': item.gstRate,
          'modifiers': item.modifiers,
          'complimentary': item.complimentary ? 1 : 0,
          'wastage': item.wastage ? 1 : 0,
        });
      }
      return orderId;
    });
  }

  Future<void> voidKot({
    required int orderId,
    required String masterActor,
    required String reason,
  }) async {
    await db.update('orders', {'status': 'VOID'},
        where: 'id = ?', whereArgs: [orderId]);
    await audit.log(
      actor: masterActor,
      action: 'KOT_VOID',
      reason: reason,
      entityId: '$orderId',
    );
  }
}
