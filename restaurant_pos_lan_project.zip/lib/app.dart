import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/providers/app_providers.dart';
import 'features/auth/presentation/startup_screen.dart';
import 'features/auth/presentation/license_lock_screen.dart';

class RestaurantPosApp extends ConsumerWidget {
  const RestaurantPosApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final license = ref.watch(licenseServiceProvider);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Restaurant POS LAN',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.deepOrange,
        brightness: Brightness.light,
      ),
      home: license.isLocked
          ? const LicenseLockScreen()
          : const StartupScreen(),
    );
  }
}
