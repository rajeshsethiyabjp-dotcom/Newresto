# Restaurant POS LAN

Offline-first single-APK Flutter restaurant POS with four roles:

- Billing & Master Admin
- Waiter / Captain
- Kitchen Display System
- Partner Read-Only

## Architecture

- Riverpod state management
- SQLite with schema migrations
- Embedded Shelf HTTP + WebSocket LAN hub on the Master device
- Firebase Firestore licensing/backup adapter
- Modular feature folders
- Audit trail for sensitive actions
- PDF Z-report generation
- ESC/POS receipt byte generation
- Dynamic UPI URI generation

## Important production setup

1. Install a current stable Flutter SDK.
2. Run `flutter pub get`.
3. Run `flutterfire configure` for your Firebase project. This replaces `lib/firebase_options.dart` with real platform options.
4. Configure Firestore security rules so a tenant can only access its own license/backup records.
5. Change the default master PIN before deployment. The demo defaults are intentionally not production credentials.
6. Set Android network permissions as included in `android/app/src/main/AndroidManifest.xml`.
7. For Android 13+, request notification/audio permissions as required by your target SDK and device policy.
8. Test printer hardware on the exact Android device model before deployment.

## Default demo credentials

- Master PIN: `1234`
- Partner PIN: `2468`

Change them before production.

## LAN model

The Master starts an HTTP/WebSocket server on port 8787. Clients on the same Wi-Fi connect to:

`ws://MASTER_IP:8787/ws`

Messages are JSON envelopes with `type`, `tenantId`, `deviceId`, and `payload`.

The LAN hub is intentionally tenant-scoped. Production deployments should additionally use a per-installation pairing secret.

## Firebase

The code is designed to work offline if Firebase is unavailable. License status is cached locally with a configurable grace period. The cloud adapter validates:

- tenant/restaurant ID
- active/blocked state
- license expiry

A remote blocked/expired status locks the UI while preserving local SQLite data.

## Build

```bash
flutter pub get
flutterfire configure
flutter run
flutter build apk --release
```

## Notes

This repository is a strong production-oriented reference implementation. Hardware-specific printer discovery/pairing and Firebase deployment configuration still require device/account configuration and field testing; no software-only project can truthfully guarantee those external integrations without the target hardware and cloud project.
