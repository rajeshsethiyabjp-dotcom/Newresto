import 'package:flutter_test/flutter_test.dart';

import 'package:restaurant_pos_lan/core/utils/upi.dart';
import 'package:restaurant_pos_lan/core/utils/security.dart';

void main() {
  test('UPI URI contains amount and currency', () {
    final uri = buildUpiUri(
      pa: 'demo@upi',
      pn: 'Demo',
      amount: 123.45,
    );
    expect(uri, contains('am=123.45'));
    expect(uri, contains('cu=INR'));
  });

  test('PIN hash verifies', () {
    final h = hashPin('1234');
    expect(verifyPin('1234', h), isTrue);
    expect(verifyPin('9999', h), isFalse);
  });
}
