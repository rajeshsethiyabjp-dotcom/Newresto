create extension if not exists pgcrypto;

create type public.license_status as enum ('active','grace','locked','expired','revoked');
create type public.member_role as enum ('owner','admin','agent','support');
create type public.tax_mode as enum ('gst','vat','none');

create table public.tenants (
 id uuid primary key default gen_random_uuid(), name text not null, legal_name text, currency char(3) not null default 'INR', timezone text not null default 'Asia/Kolkata', tax_mode public.tax_mode not null default 'gst', gstin text, fssai_no text, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.branches (
 id uuid primary key default gen_random_uuid(), tenant_id uuid not null references public.tenants(id) on delete cascade, code text not null, name text not null, address jsonb not null default '{}', timezone text, active boolean not null default true, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(tenant_id,code)
);
create table public.tenant_members (
 tenant_id uuid not null references public.tenants(id) on delete cascade, user_id uuid not null references auth.users(id) on delete cascade, role public.member_role not null, active boolean not null default true, created_at timestamptz not null default now(), primary key(tenant_id,user_id)
);
create table public.licenses (
 id uuid primary key default gen_random_uuid(), tenant_id uuid not null references public.tenants(id) on delete cascade, license_key_hash bytea not null unique, key_last4 text not null, status public.license_status not null default 'active', plan_code text not null, seats integer not null default 1 check(seats>0), issued_at timestamptz not null default now(), expires_at timestamptz not null, grace_until timestamptz not null, locked_at timestamptz, revoked_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.device_bindings (
 id uuid primary key default gen_random_uuid(), license_id uuid not null references public.licenses(id) on delete cascade, tenant_id uuid not null references public.tenants(id) on delete cascade, branch_id uuid not null references public.branches(id) on delete cascade, device_id uuid not null, role text not null, installation_id uuid not null, android_id_hash bytea, mac_hash bytea, fingerprint_hash bytea not null, first_seen_at timestamptz not null default now(), last_seen_at timestamptz not null default now(), app_version text, active boolean not null default true, unique(license_id,installation_id)
);
create table public.agent_commissions (
 id uuid primary key default gen_random_uuid(), tenant_id uuid not null references public.tenants(id) on delete cascade, agent_user_id uuid not null references auth.users(id), branch_id uuid references public.branches(id), basis_amount numeric(14,2) not null default 0, commission_rate numeric(6,3) not null default 0, commission_amount numeric(14,2) generated always as (round(basis_amount * commission_rate / 100,2)) stored, status text not null default 'pending', onboarded_at timestamptz, paid_at timestamptz, created_at timestamptz not null default now()
);
create table public.cloud_backups (
 id uuid primary key default gen_random_uuid(), tenant_id uuid not null references public.tenants(id) on delete cascade, branch_id uuid references public.branches(id) on delete cascade, device_id uuid, storage_path text not null, checksum_sha256 text not null, bytes bigint not null, created_at timestamptz not null default now()
);
create table public.support_tickets (
 id uuid primary key default gen_random_uuid(), tenant_id uuid references public.tenants(id) on delete cascade, branch_id uuid references public.branches(id) on delete cascade, device_id uuid, opened_by uuid references auth.users(id), assigned_to uuid references auth.users(id), severity text not null default 'normal', status text not null default 'open', subject text not null, description text, diagnostics jsonb not null default '{}', created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.sync_events (
 event_id uuid primary key, tenant_id uuid not null references public.tenants(id) on delete cascade, branch_id uuid not null references public.branches(id) on delete cascade, device_id uuid, entity text not null, entity_id uuid not null, operation text not null, occurred_at timestamptz not null, payload jsonb not null, accepted_at timestamptz not null default now()
);

create index branches_tenant_idx on public.branches(tenant_id);
create index devices_tenant_branch_idx on public.device_bindings(tenant_id,branch_id);
create index tickets_tenant_status_idx on public.support_tickets(tenant_id,status,updated_at desc);
create index sync_events_branch_time_idx on public.sync_events(branch_id,accepted_at,event_id);

alter table public.tenants enable row level security;
alter table public.branches enable row level security;
alter table public.tenant_members enable row level security;
alter table public.licenses enable row level security;
alter table public.device_bindings enable row level security;
alter table public.agent_commissions enable row level security;
alter table public.cloud_backups enable row level security;
alter table public.support_tickets enable row level security;
alter table public.sync_events enable row level security;

create or replace function public.is_member(p_tenant uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.tenant_members m where m.tenant_id=p_tenant and m.user_id=auth.uid() and m.active); $$;
create or replace function public.is_admin(p_tenant uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.tenant_members m where m.tenant_id=p_tenant and m.user_id=auth.uid() and m.active and m.role in ('owner','admin','support')); $$;

create policy tenant_members_self on public.tenant_members for select using (user_id=auth.uid() or public.is_member(tenant_id));
create policy tenants_member on public.tenants for select using (public.is_member(id));
create policy branches_member on public.branches for all using (public.is_member(tenant_id)) with check(public.is_member(tenant_id));
create policy licenses_admin on public.licenses for all using (public.is_admin(tenant_id)) with check(public.is_admin(tenant_id));
create policy devices_member on public.device_bindings for all using (public.is_member(tenant_id)) with check(public.is_member(tenant_id));
create policy commissions_member on public.agent_commissions for select using (public.is_member(tenant_id));
create policy backups_member on public.cloud_backups for all using (public.is_member(tenant_id)) with check(public.is_member(tenant_id));
create policy tickets_member on public.support_tickets for all using (public.is_member(tenant_id)) with check(public.is_member(tenant_id));
create policy sync_member on public.sync_events for all using (public.is_member(tenant_id)) with check(public.is_member(tenant_id));

create or replace function public.touch_updated_at() returns trigger language plpgsql as $$ begin new.updated_at=now(); return new; end $$;
create trigger tenants_touch before update on public.tenants for each row execute function public.touch_updated_at();
create trigger branches_touch before update on public.branches for each row execute function public.touch_updated_at();
create trigger licenses_touch before update on public.licenses for each row execute function public.touch_updated_at();
create trigger tickets_touch before update on public.support_tickets for each row execute function public.touch_updated_at();

create table public.agent_leads (
 id uuid primary key default gen_random_uuid(), tenant_id uuid references public.tenants(id) on delete cascade, agent_user_id uuid references auth.users(id), restaurant_name text not null, contact_name text, phone text, stage text not null default 'new', notes text, next_followup_at timestamptz, latitude numeric(10,7), longitude numeric(10,7), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.agent_checkins (
 id uuid primary key default gen_random_uuid(), tenant_id uuid not null references public.tenants(id) on delete cascade, agent_user_id uuid not null references auth.users(id), lead_id uuid references public.agent_leads(id) on delete set null, latitude numeric(10,7) not null, longitude numeric(10,7) not null, accuracy_m numeric(8,2), checked_in_at timestamptz not null default now()
);
alter table public.agent_leads enable row level security;
alter table public.agent_checkins enable row level security;
create policy leads_member on public.agent_leads for all using (public.is_member(tenant_id)) with check(public.is_member(tenant_id));
create policy checkins_member on public.agent_checkins for all using (public.is_member(tenant_id)) with check(public.is_member(tenant_id));
create trigger leads_touch before update on public.agent_leads for each row execute function public.touch_updated_at();
