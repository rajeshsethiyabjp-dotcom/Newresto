# API Contracts

Base: `/api/v1`

## Authentication
`Authorization: Bearer <supabase-access-token>`

## Device activation
`POST /licenses/activate`
```json
{"license_key":"POS-XXXX-XXXX-XXXX","device":{"installation_id":"uuid","android_id_hash":"sha256","mac_hash":"optional"}}
```
Response:
```json
{"license_id":"uuid","status":"active","expires_at":"2027-01-01T00:00:00Z","grace_until":"2027-01-08T00:00:00Z","validation_token":"opaque-short-lived-token"}
```

## Sync push
`POST /sync/push`
```json
{"events":[{"event_id":"uuid","entity":"order","entity_id":"uuid","operation":"upsert","occurred_at":"ISO-8601","payload":{}}]}
```
Response returns per-event `accepted|duplicate|conflict|rejected` plus server version.

## Sync pull
`GET /sync/pull?branch_id=<uuid>&cursor=<opaque>`
Returns ordered change events and a next cursor.

## Support diagnostics
`POST /support/diagnostics` accepts compressed structured logs, app version, device role, and health metrics. Never accept arbitrary executable payloads.

## LAN REST
- `GET /health` -> server/device capabilities.
- `GET /snapshot` -> current table/order/KOT snapshot after auth.
- `POST /kot` -> idempotent KOT submission `{event_id,kot}`.
- `POST /state` -> authenticated state mutation.

## LAN WebSocket
Client connects to `ws://<master>:8080/ws?device_id=<uuid>&nonce=<nonce>` and immediately sends:
`{"type":"hello","token":"..."}`.
Server broadcasts:
`{"type":"state","version":123,"entity":"table","data":{...}}`.
KOT acknowledgements are:
`{"type":"ack","event_id":"...","status":"accepted"}`.
