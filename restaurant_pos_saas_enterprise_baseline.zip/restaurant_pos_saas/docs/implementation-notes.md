# Implementation Notes

## POS state machines
Table state: `vacant -> running -> bill_printed -> paid`; split/merge operations create new logical bill references and preserve the original order history.

KOT state: `queued -> accepted -> preparing -> ready -> served|cancelled`.

Inventory: `on_hand = receipts + transfers_in - transfers_out - wastage - recipe_consumption`. Never mutate stock silently; every adjustment creates a journal event.

## Payment
For UPI, create a dynamic payload using the restaurant's approved VPA/acquirer configuration and exact amount. The printer service accepts a rasterized QR; a QR encoder should be implemented as a separate tested service and the payload should be validated server-side. Do not treat a displayed QR as proof of payment; payment confirmation must come from the acquiring/PSP channel or verified reconciliation.

## Hardware
The app should have platform adapters for USB/Bluetooth/LAN printer transports. The byte generator is transport-independent. For USB/Bluetooth, request the minimum platform permissions required by the chosen Android implementation.

## Remote wipe
Use a state machine (`requested`, `acknowledged`, `executing`, `completed`) with audit records. Do not wipe before the POS has uploaded unsynced financial events unless an authorized emergency policy explicitly allows data loss.
