# Production Security Checklist

- [ ] Supabase RLS enabled on every tenant-scoped table.
- [ ] Service-role key exists only on trusted backend/Edge Functions.
- [ ] License key plaintext is never logged or stored in Postgres; store a keyed hash and only display last four characters.
- [ ] Client secrets are stored with Android Keystore-backed `flutter_secure_storage`.
- [ ] LAN bearer tokens are unique per installation, rotated on pairing/revocation, and never advertised over UDP.
- [ ] WebSocket handshake validates token, tenant, branch, device and role before subscribing the socket.
- [ ] Financial documents are immutable after finalization; corrections use reversals/credit notes.
- [ ] Backups are encrypted, checksummed and retention-managed.
- [ ] Diagnostic uploads are size-limited and PII-redacted.
- [ ] Dynamic UPI QR is generated only from trusted payment configuration; verify PSP/acquirer requirements before production.
- [ ] Device wipe is authenticated, auditable, and policy-controlled.
- [ ] MAC address is not a required identity primitive on modern Android.
