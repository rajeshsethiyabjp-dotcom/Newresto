# Architecture

## Topology
1. SaaS Portal -> Supabase Auth/Postgres/Storage/Edge Functions.
2. Restaurant Master POS -> SQLite + embedded HTTP/WebSocket server + Supabase sync worker.
3. Waiter/KDS/Store devices -> LAN discovery -> authenticated WebSocket/HTTP to Master.
4. Master -> ESC/POS printers over USB/Bluetooth/LAN through platform printer adapters.
5. Cloud sync is asynchronous; local writes never wait on WAN availability.

## Tenant isolation
Every cloud business row carries `tenant_id`; branch-scoped tables additionally carry `branch_id`. RLS checks the authenticated user's tenant membership. Client requests never accept an arbitrary tenant id as authority: the server derives it from JWT claims/membership.

## Local isolation
Local SQLite is physically isolated per restaurant installation. Every entity includes `tenant_id` and `branch_id` to protect against accidental cross-branch imports. Device session tokens include tenant/branch/device claims.

## Sync model
- Every mutation gets a UUID `event_id` and `updated_at`.
- `sync_queue` records operation, entity type/id, payload, attempts, next retry and last error.
- Server endpoints are idempotent by `(tenant_id,event_id)`.
- Deletes are tombstoned, not hard-deleted, until retention permits compaction.
- Conflict policy: orders/KOT state is last-write-wins only for monotonic state transitions; financial documents are immutable after finalization and corrected with reversal documents.

## Licensing/security
License secrets are generated server-side. Client stores only encrypted local state and a short-lived validation token. Never put the license master secret in the APK. Remote lock/wipe means: reject new sessions, stop sync, hide operational UI, and optionally purge encrypted local business data after an explicit authenticated wipe command. A remote wipe should not silently destroy accounting evidence.

## Discovery
UDP broadcast is best-effort and mDNS is preferred where available. Discovery packets contain no credentials. A discovered endpoint must still complete authenticated pairing before receiving business data.

## Printing
Printer routing is configuration-driven: counter, kitchen, bar, and fallback. ESC/POS byte generation is deterministic. QR printing is delegated to a platform printer transport and supports a raster bitmap fallback.

## Observability
Use structured events with tenant/branch/device correlation IDs. Do not log customer PII, credentials, payment secrets, or raw license keys.
