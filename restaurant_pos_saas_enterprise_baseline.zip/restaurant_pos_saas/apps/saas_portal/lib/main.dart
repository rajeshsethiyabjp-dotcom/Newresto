import 'package:flutter/material.dart';

void main() => runApp(const SaaSPortalApp());

class SaaSPortalApp extends StatelessWidget {
  const SaaSPortalApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'POS SaaS Portal',
        theme: ThemeData(useMaterial3: true),
        home: Scaffold(
          appBar: AppBar(title: const Text('POS SaaS Portal')),
          body: const Center(child: Text('Cloud Admin / Support / Field Portal')),
        ),
      );
}
