import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:restaurant_pos/features/billing/thermal_printer_service.dart';

void main() {
  test('receipt contains ESC/POS init and total', () {
    final bytes = ThermalPrinterService().receipt(restaurant: 'Test', address: 'Indore', billNo: 'B1', lines: const [ReceiptLine(name: 'Paneer', qty: 2, totalMinor: 24000)], totalMinor: 24000);
    expect(bytes.first, 0x1B);
    expect(bytes, contains(0x40));
  });
  test('QR raster validates dimensions', () {
    final bytes = ThermalPrinterService().qrBitmap(bitmap: Uint8List.fromList(List.filled(64, 0)), width: 8, height: 8);
    expect(bytes.sublist(0, 4), [0x1D, 0x76, 0x30, 0]);
  });
}
