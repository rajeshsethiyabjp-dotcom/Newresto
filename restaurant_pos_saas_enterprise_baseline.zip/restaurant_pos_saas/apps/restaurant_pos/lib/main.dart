import 'package:flutter/material.dart';

void main() => runApp(const RestaurantPosApp());

class RestaurantPosApp extends StatelessWidget {
  const RestaurantPosApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(title: 'Restaurant POS', theme: ThemeData(useMaterial3: true), home: const RoleSelector());
}

class RoleSelector extends StatelessWidget {
  const RoleSelector({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Select POS Role')), body: ListView(children: const [ListTile(title: Text('Admin / Billing Counter')), ListTile(title: Text('Waiter / Captain')), ListTile(title: Text('Kitchen Display')), ListTile(title: Text('Store / Inventory Manager'))]));
}
