import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as shelf_io;
import 'package:shelf_web_socket/shelf_web_socket.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

class LocalServerService {
  LocalServerService({required this.authToken, Future<Map<String, dynamic>> Function()? snapshotProvider}) : _snapshotProvider = snapshotProvider ?? (() async => const {'version': 0});

  final String authToken;
  final Future<Map<String, dynamic>> Function() _snapshotProvider;
  HttpServer? _server;
  final Set<WebSocketChannel> _clients = <WebSocketChannel>{};
  int _version = 0;

  bool get running => _server != null;
  int get port => _server?.port ?? 8080;

  Future<void> start({InternetAddress? bindAddress, int port = 8080}) async {
    if (running) return;
    final address = bindAddress ?? InternetAddress.anyIPv4;
    final wsHandler = webSocketHandler((WebSocketChannel socket, String? protocol) {
      socket.stream.listen((message) async {
        try {
          final map = jsonDecode(message as String) as Map<String, dynamic>;
          if (map['type'] == 'hello' && map['token'] == authToken) {
            socket.sink.add(jsonEncode({'type': 'hello_ack', 'version': _version}));
          } else if (map['token'] == authToken && map['type'] == 'kot') {
            broadcast({'type': 'kot', 'version': ++_version, 'data': map['data']});
            socket.sink.add(jsonEncode({'type': 'ack', 'event_id': map['event_id'], 'status': 'accepted'}));
          } else {
            socket.sink.add(jsonEncode({'type': 'error', 'code': 'unauthorized'}));
          }
        } catch (_) {
          socket.sink.add(jsonEncode({'type': 'error', 'code': 'bad_message'}));
        }
      }, onDone: () => _clients.remove(socket), onError: (_) => _clients.remove(socket));
      _clients.add(socket);
    });

    final handler = const Pipeline().addMiddleware(logRequests()).addHandler((Request request) async {
      if (request.url.path == 'ws') return wsHandler(request);
      if (request.url.path == 'health' && request.method == 'GET') {
        return Response.ok(jsonEncode({'ok': true, 'version': _version, 'port': port}), headers: {'content-type': 'application/json'});
      }
      if (request.headers['authorization'] != 'Bearer $authToken') return Response.forbidden(jsonEncode({'error': 'unauthorized'}));
      if (request.url.path == 'snapshot' && request.method == 'GET') return Response.ok(jsonEncode(await _snapshotProvider()), headers: {'content-type': 'application/json'});
      if (request.url.path == 'kot' && request.method == 'POST') {
        final body = await request.readAsString();
        final map = jsonDecode(body) as Map<String, dynamic>;
        broadcast({'type': 'kot', 'version': ++_version, 'data': map});
        return Response.ok(jsonEncode({'status': 'accepted', 'version': _version}), headers: {'content-type': 'application/json'});
      }
      return Response.notFound(jsonEncode({'error': 'not_found'}));
    });

    _server = await shelf_io.serve(handler, address, port, shared: true);
  }

  void broadcast(Map<String, dynamic> event) {
    final encoded = jsonEncode(event);
    for (final client in List<WebSocketChannel>.from(_clients)) {
      try {
        client.sink.add(encoded);
      } catch (_) {
        _clients.remove(client);
      }
    }
  }

  Future<void> stop() async {
    for (final c in List<WebSocketChannel>.from(_clients)) {
      await c.sink.close();
    }
    _clients.clear();
    await _server?.close(force: true);
    _server = null;
  }
}
