import 'dart:async';
import 'dart:convert';
import 'dart:io';

class MasterEndpoint {
  const MasterEndpoint({required this.address, required this.port, required this.deviceId});
  final InternetAddress address;
  final int port;
  final String deviceId;
}

class LanDiscoveryService {
  LanDiscoveryService({this.discoveryPort = 45454});
  final int discoveryPort;
  RawDatagramSocket? _socket;
  StreamSubscription<RawSocketEvent>? _subscription;

  Future<void> announce({required String deviceId, int masterPort = 8080}) async {
    _socket ??= await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0, reuseAddress: true, reusePort: true);
    _socket!.broadcastEnabled = true;
    final payload = jsonEncode({'type': 'pos_master', 'device_id': deviceId, 'port': masterPort, 'protocol': 1});
    _socket!.send(utf8.encode(payload), InternetAddress('255.255.255.255'), discoveryPort);
  }

  Future<Stream<MasterEndpoint>> listen({Duration timeout = const Duration(seconds: 5)}) async {
    await _subscription?.cancel();
    final socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, discoveryPort, reuseAddress: true, reusePort: true);
    _socket = socket;
    final controller = StreamController<MasterEndpoint>();
    _subscription = socket.where((e) => e == RawSocketEvent.read).listen((_) {
      Datagram? d;
      while ((d = socket.receive()) != null) {
        try {
          final map = jsonDecode(utf8.decode(d!.data)) as Map<String, dynamic>;
          if (map['type'] == 'pos_master' && map['device_id'] is String && map['port'] is int) controller.add(MasterEndpoint(address: d.address, port: map['port'] as int, deviceId: map['device_id'] as String));
        } catch (_) {}
      }
    });
    Timer(timeout, () async { await controller.close(); await _subscription?.cancel(); });
    return controller.stream;
  }

  Future<void> dispose() async {
    await _subscription?.cancel();
    _socket?.close();
    _socket = null;
  }
}
