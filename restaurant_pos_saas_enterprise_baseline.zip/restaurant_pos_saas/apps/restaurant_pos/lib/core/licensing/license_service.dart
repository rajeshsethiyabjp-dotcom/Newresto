import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:uuid/uuid.dart';

class LicenseState {
  const LicenseState({required this.status, this.expiresAt, this.graceUntil, this.validationToken});
  final String status;
  final DateTime? expiresAt;
  final DateTime? graceUntil;
  final String? validationToken;
  bool get isUsable {
    final now = DateTime.now().toUtc();
    if (status == 'active') return expiresAt == null || now.isBefore(expiresAt!);
    return status == 'grace' && graceUntil != null && now.isBefore(graceUntil!);
  }
}

class LicenseService {
  LicenseService({Dio? dio, FlutterSecureStorage? storage, DeviceInfoPlugin? deviceInfo})
      : _dio = dio ?? Dio(), _storage = storage ?? const FlutterSecureStorage(), _deviceInfo = deviceInfo ?? DeviceInfoPlugin();

  static const _licenseKey = 'license.key';
  static const _stateKey = 'license.state';
  static const _installKey = 'license.installation';
  final Dio _dio;
  final FlutterSecureStorage _storage;
  final DeviceInfoPlugin _deviceInfo;

  Future<String> installationId() async {
    final existing = await _storage.read(key: _installKey);
    if (existing != null && existing.isNotEmpty) return existing;
    final id = const Uuid().v4();
    await _storage.write(key: _installKey, value: id);
    return id;
  }

  Future<String> androidIdHash() async {
    final info = await _deviceInfo.androidInfo;
    return sha256.convert(utf8.encode(info.id)).toString();
  }

  // Android 10+ does not expose a stable Wi-Fi MAC to ordinary apps. This is intentionally optional.
  Future<String?> optionalMacHash() async => null;

  Future<String> fingerprintHash() async {
    final install = await installationId();
    final android = await androidIdHash();
    final mac = await optionalMacHash() ?? 'unavailable';
    return sha256.convert(utf8.encode('$install|$android|$mac')).toString();
  }

  Future<LicenseState?> loadCached() async {
    final raw = await _storage.read(key: _stateKey);
    if (raw == null) return null;
    try {
      final m = jsonDecode(raw) as Map<String, dynamic>;
      return LicenseState(
        status: m['status'] as String,
        expiresAt: m['expiresAt'] == null ? null : DateTime.parse(m['expiresAt'] as String),
        graceUntil: m['graceUntil'] == null ? null : DateTime.parse(m['graceUntil'] as String),
        validationToken: m['validationToken'] as String?,
      );
    } catch (_) {
      return null;
    }
  }

  Future<LicenseState> activate({required String licenseKey, required String baseUrl, required String branchId, required String role}) async {
    final fingerprint = await fingerprintHash();
    final payload = {
      'license_key': licenseKey.trim().toUpperCase(),
      'device': {
        'installation_id': await installationId(),
        'android_id_hash': await androidIdHash(),
        'mac_hash': await optionalMacHash(),
        'fingerprint_hash': fingerprint,
        'branch_id': branchId,
        'role': role,
      },
    };
    final response = await _dio.post('$baseUrl/licenses/activate', data: payload, options: Options(sendTimeout: const Duration(seconds: 8), receiveTimeout: const Duration(seconds: 8)));
    final data = Map<String, dynamic>.from(response.data as Map);
    final state = LicenseState(
      status: data['status'] as String,
      expiresAt: DateTime.tryParse(data['expires_at'] as String? ?? ''),
      graceUntil: DateTime.tryParse(data['grace_until'] as String? ?? ''),
      validationToken: data['validation_token'] as String?,
    );
    await _storage.write(key: _licenseKey, value: licenseKey.trim().toUpperCase());
    await _storage.write(key: _stateKey, value: jsonEncode({'status': state.status, 'expiresAt': state.expiresAt?.toIso8601String(), 'graceUntil': state.graceUntil?.toIso8601String(), 'validationToken': state.validationToken}));
    return state;
  }

  Future<LicenseState> validateOrUseGrace({required String baseUrl}) async {
    final cached = await loadCached();
    if (cached == null) throw StateError('License is not activated');
    final key = await _storage.read(key: _licenseKey);
    if (key == null) throw StateError('License key is missing');
    try {
      final response = await _dio.post('$baseUrl/licenses/validate', data: {'license_key': key, 'fingerprint_hash': await fingerprintHash()}, options: Options(sendTimeout: const Duration(seconds: 5), receiveTimeout: const Duration(seconds: 5)));
      final d = Map<String, dynamic>.from(response.data as Map);
      final fresh = LicenseState(status: d['status'] as String, expiresAt: DateTime.tryParse(d['expires_at'] as String? ?? ''), graceUntil: DateTime.tryParse(d['grace_until'] as String? ?? ''), validationToken: d['validation_token'] as String?);
      await _storage.write(key: _stateKey, value: jsonEncode({'status': fresh.status, 'expiresAt': fresh.expiresAt?.toIso8601String(), 'graceUntil': fresh.graceUntil?.toIso8601String(), 'validationToken': fresh.validationToken}));
      return fresh;
    } on DioException {
      final now = DateTime.now().toUtc();
      if (cached.status == 'active' && cached.expiresAt != null && now.isBefore(cached.expiresAt!)) return cached;
      if (cached.graceUntil != null && now.isBefore(cached.graceUntil!)) return LicenseState(status: 'grace', expiresAt: cached.expiresAt, graceUntil: cached.graceUntil, validationToken: cached.validationToken);
      throw StateError('License validation unavailable and offline grace period has expired');
    }
  }
}
