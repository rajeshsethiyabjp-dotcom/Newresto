import 'dart:convert';
import 'dart:typed_data';

class ThermalPrinterService {
  static const esc = 0x1B;
  static const gs = 0x1D;

  Uint8List receipt({required String restaurant, required String address, required String billNo, required List<ReceiptLine> lines, required int totalMinor, String? gstin, String? footer}) {
    final b = BytesBuilder(copy: false);
    b.add([esc, 0x40, esc, 0x61, 0x01]);
    b.add(_text('$restaurant\n'));
    b.add(_text('$address\n'));
    if (gstin != null && gstin.isNotEmpty) b.add(_text('GSTIN: $gstin\n'));
    b.add(_text('Bill: $billNo\n'));
    b.add([esc, 0x61, 0x00]);
    b.add(_text('--------------------------------\n'));
    for (final line in lines) b.add(_line(line));
    b.add(_text('--------------------------------\n'));
    b.add([esc, 0x45, 0x01]);
    b.add(_text('TOTAL ${_money(totalMinor)}\n'));
    b.add([esc, 0x45, 0x00]);
    if (footer != null && footer.isNotEmpty) b.add(_text('$footer\n'));
    b.add([0x0A, 0x0A, 0x0A, esc, 0x64, 0x03]);
    return b.toBytes();
  }

  Uint8List kot({required String kotNo, required String station, required String table, required List<ReceiptLine> lines}) {
    final b = BytesBuilder(copy: false)..add([esc,0x40,esc,0x61,0x01,esc,0x45,0x01]);
    b.add(_text('KOT $kotNo\n'));
    b.add([esc,0x45,0x00,esc,0x61,0x00]);
    b.add(_text('Station: $station  Table: $table\n'));
    b.add(_text('--------------------------------\n'));
    for (final l in lines) b.add(_text('${_qty(l.qty)} x ${l.name}\n${l.note == null ? '' : '  NOTE: ${l.note}\n'}'));
    b.add(_text('\n'));
    return b.toBytes();
  }

  // bitmap must be 1-bit packed, row-major, MSB first. This emits ESC/POS GS v 0 raster format.
  Uint8List qrBitmap({required Uint8List bitmap, required int width, required int height, int threshold = 128}) {
    if (width <= 0 || height <= 0) throw ArgumentError('Invalid bitmap dimensions');
    final rowBytes = (width + 7) ~/ 8;
    if (bitmap.length != width * height) throw ArgumentError('Bitmap must contain width*height grayscale bytes');
    final packed = Uint8List(rowBytes * height);
    for (var y = 0; y < height; y++) {
      for (var x = 0; x < width; x++) {
        if (bitmap[y * width + x] < threshold) packed[y * rowBytes + (x ~/ 8)] |= (0x80 >> (x % 8));
      }
    }
    final out = BytesBuilder(copy: false)..add([gs,0x76,0x30,0x00,rowBytes & 0xFF,(rowBytes >> 8) & 0xFF,height & 0xFF,(height >> 8) & 0xFF])..add(packed);
    return out.toBytes();
  }

  Uint8List _line(ReceiptLine l) {
    final left = '${_qty(l.qty)} ${l.name}';
    final right = _money(l.totalMinor);
    const width = 32;
    final clipped = left.length > width - right.length - 1 ? '${left.substring(0, width - right.length - 2)}…' : left;
    return _text('$clipped${' ' * (width - clipped.length - right.length)}$right\n');
  }
  List<int> _text(String value) => latin1.encode(value.replaceAll('₹', 'Rs '));
  String _money(int minor) => 'Rs ${(minor / 100).toStringAsFixed(2)}';
  String _qty(double qty) => qty == qty.roundToDouble() ? qty.toInt().toString() : qty.toStringAsFixed(2);
}

class ReceiptLine {
  const ReceiptLine({required this.name, required this.qty, required this.totalMinor, this.note});
  final String name;
  final double qty;
  final int totalMinor;
  final String? note;
}
