import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';

enum IndentStatus { draft, submitted, approved, poGenerated, dispatched, failed }

class IndentLine {
  const IndentLine({required this.materialId, required this.qty, required this.unit, this.approvedQty});
  final String materialId;
  final double qty;
  final String unit;
  final double? approvedQty;
}

class IndentWorkflowState {
  const IndentWorkflowState({required this.status, this.indentId, this.poId, this.error, this.lines = const []});
  final IndentStatus status;
  final String? indentId;
  final String? poId;
  final String? error;
  final List<IndentLine> lines;
  IndentWorkflowState copyWith({IndentStatus? status, String? indentId, String? poId, String? error, List<IndentLine>? lines}) => IndentWorkflowState(status: status ?? this.status, indentId: indentId ?? this.indentId, poId: poId ?? this.poId, error: error, lines: lines ?? this.lines);
}

abstract interface class InventoryWorkflowRepository {
  Future<String> createIndent(List<IndentLine> lines);
  Future<void> submitIndent(String indentId);
  Future<List<IndentLine>> approveIndent(String indentId);
  Future<String> generatePo(String indentId, List<IndentLine> approvedLines, String vendorId);
  Future<void> dispatchPo(String poId);
}

class IndentToPoController extends StateNotifier<IndentWorkflowState> {
  IndentToPoController(this._repo) : super(const IndentWorkflowState(status: IndentStatus.draft));
  final InventoryWorkflowRepository _repo;
  bool _busy = false;

  Future<void> run({required List<IndentLine> lines, required String vendorId}) async {
    if (_busy) return;
    if (lines.isEmpty) return _fail('At least one material line is required');
    if (vendorId.trim().isEmpty) return _fail('Vendor is required');
    _busy = true;
    try {
      final indentId = await _repo.createIndent(lines);
      state = state.copyWith(indentId: indentId, status: IndentStatus.submitted, lines: lines, error: null);
      await _repo.submitIndent(indentId);
      final approved = await _repo.approveIndent(indentId);
      state = state.copyWith(status: IndentStatus.approved, lines: approved);
      final poId = await _repo.generatePo(indentId, approved, vendorId);
      state = state.copyWith(status: IndentStatus.poGenerated, poId: poId);
      await _repo.dispatchPo(poId);
      state = state.copyWith(status: IndentStatus.dispatched);
    } catch (e) {
      state = state.copyWith(status: IndentStatus.failed, error: e.toString());
    } finally {
      _busy = false;
    }
  }

  void _fail(String message) => state = state.copyWith(status: IndentStatus.failed, error: message);
}

final indentToPoControllerProvider = StateNotifierProvider<IndentToPoController, IndentWorkflowState>((ref) {
  throw UnimplementedError('Override this provider with a tenant/branch scoped InventoryWorkflowRepository');
});
