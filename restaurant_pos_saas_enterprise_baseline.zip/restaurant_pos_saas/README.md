# Restaurant POS SaaS — Production Architecture Baseline

This repository is a production-oriented baseline for a two-app Flutter/Supabase restaurant POS platform.

## Important platform constraints
- Flutter/Dart code targets Flutter 3.24.5+ / Dart 3.5+ syntax and avoids deprecated Android V1 embedding APIs.
- Android 10+ generally does **not** expose a stable hardware Wi-Fi MAC address to normal applications. The licensing implementation therefore uses Android ID + an app-generated installation key and treats MAC as an optional, non-authoritative signal. Do not design licensing around a MAC address as a guaranteed identifier.
- The local master server is intentionally bound to the LAN interface, not 0.0.0.0 by default, and uses a per-installation bearer secret. In production, rotate this secret and pair devices using an authenticated handshake.
- Offline POS transactions are locally authoritative until synchronized. Cloud records are append-only/idempotent where practical.

## Repository
- `apps/restaurant_pos`: offline-first POS, embedded LAN server/discovery, inventory, printing.
- `apps/saas_portal`: cloud-connected admin/field/support app skeleton.
- `backend/supabase/migrations`: PostgreSQL schema, RLS, indexes and core functions.
- `docs/architecture.md`: topology, consistency model, security and deployment guidance.
- `docs/api-contracts.md`: REST/WebSocket contracts.

## Validation
The environment used to assemble this archive does not contain the Flutter/Dart SDK, so a real `flutter analyze`/`flutter test` execution was not possible here. The package is structured and reviewed for Dart type/syntax compatibility, but it should be run through CI with the pinned Flutter toolchain before production deployment.
